package com.mrc.rcdit;

import android.app.Activity;
import android.os.Bundle;
import android.media.projection.MediaProjectionManager;
import android.content.*;

public class SActivity extends Activity {
	
	private static boolean fromService = false;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		if(fromService){
			fromService = false;
			MediaProjectionManager manager = store.getMediaProjectionManager();
			startActivityForResult(manager.createScreenCaptureIntent(), 990);
			if(store.getContext() != null && store.allowToUseContext){
				((Activity)store.getContext()).finish();
			}
		}else{
			finish();
		}
	}
	
	public static void set(boolean i){
		fromService = i;
	}
	
	protected void onActivityResult(int requestCode, int resultCode, Intent intent) {
		super.onActivityResult(requestCode, resultCode, intent);
		try{ 
			if(store.getResultInterface() != null){
				store.getResultInterface().onResult(resultCode, intent);
			}
		}catch(Exception e){
		}
		finish();
	}
	
}
