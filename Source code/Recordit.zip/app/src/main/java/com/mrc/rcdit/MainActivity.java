package com.mrc.rcdit;

import android.animation.*;
import android.app.*;
import android.content.*;
import android.content.Intent;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.os.Bundle;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.*;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import java.io.*;
import java.io.InputStream;
import java.text.*;
import java.util.*;
import java.util.regex.*;
import org.json.*;
import java.io.*;
import androidx.core.content.FileProvider;
import android.provider.Settings; 
import android.content.pm.PackageManager;
import android.Manifest;

public class MainActivity extends AppCompatActivity {
	
	private LinearLayout linear1;
	private FrameLayout linear5;
	private TextView textview5;
	private TextView textview3;
	private ImageView imageview3;
	private TextView textview2;
	private LinearLayout lininfo;
	private LinearLayout linear9;
	private ImageView imginfo;
	private ImageView imageview1;
	private ScrollView vscroll1;
	private LinearLayout linear6;
	private LinearLayout bar_;
	private FrameLayout linear2;
	private LinearLayout linear4;
	private ImageView imageview4;
	private TextView textview4;
	private LinearLayout linear10;
	private TextView textview11;
	private ImageView mrc;
	private TextView textview6;
	private LinearLayout linear7;
	private TextView textview7;
	private LinearLayout linear8;
	private TextView textview8;
	private ImageView imageview7;
	private ImageView imageview8;
	private ImageView imageview2;
	
	private Intent inf = new Intent();
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.main);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		linear1 = findViewById(R.id.linear1);
		linear5 = findViewById(R.id.linear5);
		textview5 = findViewById(R.id.textview5);
		textview3 = findViewById(R.id.textview3);
		imageview3 = findViewById(R.id.imageview3);
		textview2 = findViewById(R.id.textview2);
		lininfo = findViewById(R.id.lininfo);
		linear9 = findViewById(R.id.linear9);
		imginfo = findViewById(R.id.imginfo);
		imageview1 = findViewById(R.id.imageview1);
		vscroll1 = findViewById(R.id.vscroll1);
		linear6 = findViewById(R.id.linear6);
		bar_ = findViewById(R.id.bar_);
		linear2 = findViewById(R.id.linear2);
		linear4 = findViewById(R.id.linear4);
		imageview4 = findViewById(R.id.imageview4);
		textview4 = findViewById(R.id.textview4);
		linear10 = findViewById(R.id.linear10);
		textview11 = findViewById(R.id.textview11);
		mrc = findViewById(R.id.mrc);
		textview6 = findViewById(R.id.textview6);
		linear7 = findViewById(R.id.linear7);
		textview7 = findViewById(R.id.textview7);
		linear8 = findViewById(R.id.linear8);
		textview8 = findViewById(R.id.textview8);
		imageview7 = findViewById(R.id.imageview7);
		imageview8 = findViewById(R.id.imageview8);
		imageview2 = findViewById(R.id.imageview2);
		
		lininfo.setOnLongClickListener(new View.OnLongClickListener() {
			@Override
			public boolean onLongClick(View _view) {
				SketchwareUtil.showMessage(getApplicationContext(), "About Us!");
				return true;
			}
		});
		
		lininfo.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				inf.setClass(getApplicationContext(), InfoActivity.class);
				startActivity(inf);
			}
		});
		
		linear9.setOnLongClickListener(new View.OnLongClickListener() {
			@Override
			public boolean onLongClick(View _view) {
				SketchwareUtil.showMessage(getApplicationContext(), "Settings!");
				return true;
			}
		});
		
		linear9.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				
				startActivity(new Intent(getApplicationContext(), SttActivity.class));
				
			}
		});
		
		mrc.setOnLongClickListener(new View.OnLongClickListener() {
			@Override
			public boolean onLongClick(View _view) {
				SketchwareUtil.CustomToast(getApplicationContext(), "By MicroResearch Corpration", 0xFF9C27B0, 18, 0xFFFFFFFF, 25, SketchwareUtil.BOTTOM);
				inf.setClass(getApplicationContext(), InfoActivity.class);
				startActivity(inf);
				return true;
			}
		});
		
		linear7.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				
				//Iterator var2 = more_list.values().iterator(); 
				int var3 = 0; 
				SharedPreferences var2 = getSharedPreferences("_files_array", 0); 
				
				try{
						JSONArray jghgg = new JSONArray(var2.getString("_files", new JSONArray().toString())); 
						
						for(int o = 0; o < jghgg.length(); o++){
								if(more_list.get(jghgg.getString(o)) != null && more_list.get(jghgg.getString(o)).getId() == 1){
										++var3; 
								}
						}
				}catch(Exception uzzz){
				}
				
				
				new DialogBox().setClickEvent(new DialogClickEvent() { 
						public void onCancel() { 
						} 
						
						public void onYes() { 
								boolean var10001; 
								SharedPreferences var2; 
								JSONArray var3; 
								try { 
										var2 = getSharedPreferences("_files_array", 0); 
										var3 = new JSONArray(var2.getString("_files", new JSONArray().toString())); 
								} catch (Exception var17) { 
										var10001 = false; 
										return; 
								} 
								
								int var4 = 0; 
								
								JSONArray var5; 
								while(true) { 
										try { 
												if (var4 >= var3.length()) { 
														var5 = new JSONArray(); 
														break; 
												} 
										} catch (Exception var21) { 
												var10001 = false; 
												return; 
										} 
										
										label104: { 
												LinearLayout var12; 
												try { 
														if (((ImageView)more_list.get(var3.getString(var4))).getId() != 1) { 
																break label104; 
														} 
														
														TranslateAnimation var11 = new TranslateAnimation(0.0F, 0.0F, 0.0F, -200.0F); 
														var11.setDuration(400L); 
														var12 = (LinearLayout)lay_list.get(var3.getString(var4)); 
														var12.setAnimation(var11); 
												} catch (Exception var22) { 
														var10001 = false; 
														return; 
												} 
												
												if (var12 != null) { 
														try { 
																if (var12.getParent() != null) { 
																		((ViewGroup)var12.getParent()).removeView(var12); 
																} 
														} catch (Exception var16) { 
																var10001 = false; 
																return; 
														} 
												} 
												
												try { 
														var3.put(var4, "null"); 
												} catch (Exception var15) { 
														var10001 = false; 
														return; 
												} 
										} 
										
										++var4; 
								} 
								
								int var6 = 0; 
								
								Iterator var9; 
								while(true) { 
										try { 
												if (var6 >= var3.length()) { 
														showBar(false); 
														ckeckedShowing = false; 
														var9 = more_list.values().iterator(); 
														break; 
												} 
										} catch (Exception var19) { 
												var10001 = false; 
												return; 
										} 
										
										try { 
												String var7 = var3.getString(var6); 
												if (!var7.equals("null")) { 
														var5.put(var7); 
												} 
										} catch (Exception var20) { 
												var10001 = false; 
												return; 
										} 
										
										++var6; 
								} 
								
								while(true) { 
										try { 
												if (!var9.hasNext()) { 
														var2.edit().putString("_files", var5.toString()).apply(); 
														if (var5.length() != 0) { 
																break; 
														} 
														
														linear6.setVisibility(0); 
														return; 
												} 
										} catch (Exception var18) { 
												var10001 = false; 
												return; 
										} 
										
										try { 
												ImageView var10 = (ImageView)var9.next(); 
												var10.setImageDrawable(MainActivity.this.getResources().getDrawable(2130837534)); 
												var10.setId(0); 
										} catch (Exception var14) { 
												var10001 = false; 
												return; 
										} 
								} 
								
								try { 
										linear6.setVisibility(8); 
								} catch (Exception var13) { 
										var10001 = false; 
								} 
						} 
				}).setMessage("Do you want to remove " + var3 + " selected videos?").show(); 
				
			}
		});
		
		linear8.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				
				if (all_checked) { 
						all_checked = false; 
						Iterator var4 = more_list.values().iterator(); 
						
						while(var4.hasNext()) { 
								ImageView var5 = (ImageView)var4.next(); 
								var5.setImageDrawable(getResources().getDrawable(R.drawable.unchecked_box)); 
								var5.setId(2); 
						} 
						
						imageview8.setImageDrawable(getResources().getDrawable(R.drawable.select_all)); 
				} else { 
						all_checked = true; 
						Iterator var2 = more_list.values().iterator(); 
						
						while(var2.hasNext()) { 
								ImageView var3 = (ImageView)var2.next(); 
								var3.setImageDrawable(getResources().getDrawable(R.drawable.checked_box)); 
								var3.setId(1); 
						} 
						
						imageview8.setImageDrawable(getResources().getDrawable(R.drawable.remove_selection)); 
				} 
				
				
			}
		});
		
		imageview2.setOnLongClickListener(new View.OnLongClickListener() {
			@Override
			public boolean onLongClick(View _view) {
				SketchwareUtil.showMessage(getApplicationContext(), "Start Recording!");
				return true;
			}
		});
		
		imageview2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				
				if (MainActivity.allow_all_Permission(MainActivity.this)) { 
						if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(MainActivity.this.getApplicationContext())) { 
								startActivityForResult(new Intent("android.settings.action.MANAGE_OVERLAY_PERMISSION", Uri.parse("package:" + getPackageName())), 7777); 
						} else { 
								store.toAllowUseContext(false); 
								Intent var2 = new Intent(); 
								var2.setClass(getApplicationContext(), window_service.class); 
								startService(var2); 
						} 
				} else { 
						getPermission(); 
				} 
				
			}
		});
	}
	
	private void initializeLogic() {
		store.setContext(MainActivity.this);
		getSharedPreferences("_data_settings", Context.MODE_PRIVATE).edit().putInt("_device_height", getHeight(MainActivity.this)).apply();
		        
		window_service.setListener(new window_service.Listener(){
			    public void onStop(){
				        update();
				    }
		});
		
		imageview7.setImageDrawable(getResources().getDrawable(R.drawable.delete_48px));
		imageview8.setImageDrawable(getResources().getDrawable(R.drawable.select_all));
		
		GradientDrawable vaggght = new GradientDrawable();
		vaggght.setColor(0xFFFFFFFF);
		linear1.setBackground(vaggght);
		linear1.setElevation(5);
		
		if(!allow_all_Permission(MainActivity.this)){
			    getPermission();
		}
		
		
		getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
		bar_.setVisibility(View.GONE);
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		if (_requestCode == 7777) { 
						store.toAllowUseContext(false); 
						Intent var4 = new Intent(); 
						var4.setClass(getApplicationContext(), window_service.class); 
						startService(var4); 
						showMessage("Start Recording"); 
			} 
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	
	@Override
	public void onResume() {
		super.onResume();
		update();
	}
	
	@Override
	public void onBackPressed() {
		
		if(ckeckedShowing){
				showBar(false); 
				ckeckedShowing = false; 
				Iterator varr = more_list.values().iterator(); 
				while(varr.hasNext()) { 
						ImageView var2 = (ImageView)varr.next(); 
						var2.setImageDrawable(getResources().getDrawable(R.drawable.more_icon)); 
						var2.setId(0); 
				} 
		}else{
				finish();	
		}
		
	}
	public void _bb() {
	}
	
	
	static HashMap thm_map = new HashMap(); 
	boolean all_checked = false; 
	boolean ckeckedShowing = false; 
	HashMap lay_list = new HashMap(); 
	ArrayList metaData_list = new ArrayList(); 
	HashMap<String, ImageView> more_list = new HashMap(); 
	
	static boolean allow_all_Permission(Context c) { 
			boolean is = true; 
			if (Build.VERSION.SDK_INT >= 23 && (c.checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED || c.checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED || c.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_DENIED)) { 
					is = false; 
			} 
			return is; 
	} 
	
	void add_For_ExtractData(ImageView img, TextView ttv, String path) { 
			metaData dt = new metaData(img, ttv, path); 
			metaData_list.add(dt); 
	} 
	
	
	void getPermission() { 
			requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.RECORD_AUDIO}, 900); 
	} 
	
	void appendNewVideo(String var1) { 
			LinearLayout var2 = (LinearLayout)((LinearLayout)LayoutInflater.from(this).inflate(R.layout.hgg, null)).findViewById(R.id.vd_bck); 
			var2.setTag(var1); 
			if (var2.getParent() != null) { 
					((ViewGroup)var2.getParent()).removeView(var2); 
			} 
			
			TranslateAnimation var3 = new TranslateAnimation(0.0F, 0.0F, -200.0F, 0.0F); 
			var3.setDuration(400L); 
			var2.setAnimation(var3); 
			linear4.addView(var2); 
			lay_list.put(var1, var2); 
			File var5 = new File(var1); 
			ImageView var6 = (ImageView)var2.findViewById(R.id.thum_v); 
			TextView var7 = (TextView)var2.findViewById(R.id.time_v); 
			TextView var8 = (TextView)var2.findViewById(R.id.ttl_v); 
			TextView var9 = (TextView)var2.findViewById(R.id.inf_v); 
			ImageView var10 = (ImageView)var2.findViewById(R.id.mr_v); 
			if (ckeckedShowing) { 
					var10.setImageDrawable(getResources().getDrawable(R.drawable.unchecked_box)); 
					var10.setId(2); 
			} else { 
					var10.setImageDrawable(getResources().getDrawable(R.drawable.more_icon)); 
					var10.setId(0); 
			} 
			
			var10.setTag(var1); 
			more_list.put(var1, var10); 
			if (var1.endsWith(".mp3")) { 
					var6.setImageResource(R.drawable.bbbvv_1); 
			} 
			
			var8.setText(var5.getName()); 
			var9.setText("Size : " + byte_to(var5.length())); 
			add_For_ExtractData(var6, var7, var1); 
			var2.setOnClickListener(new OnClickListener() { 
					public void onClick(View var1) { 
							if (MainActivity.this.ckeckedShowing) { 
									ImageView var2 = (ImageView)more_list.get(var1.getTag().toString()); 
									if (var2.getId() == 1) { 
											var2.setId(0); 
											var2.setImageDrawable(getResources().getDrawable(R.drawable.unchecked_box)); 
									} else { 
											var2.setId(1); 
											var2.setImageDrawable(getResources().getDrawable(R.drawable.checked_box)); 
									} 
							} else { 
									openWith(var1.getTag().toString()); 
							} 
					} 
			}); 
			var2.setOnLongClickListener(new OnLongClickListener() { 
					public boolean onLongClick(View var1) { 
							if (ckeckedShowing) { 
									showBar(false); 
									ckeckedShowing = false; 
									Iterator var4 = more_list.values().iterator(); 
									
									while(var4.hasNext()) { 
											ImageView var5 = (ImageView)var4.next(); 
											var5.setImageDrawable(getResources().getDrawable(R.drawable.more_icon)); 
											var5.setId(0); 
									} 
							} else { 
									showBar(true); 
									ckeckedShowing = true; 
									Iterator var2 = more_list.values().iterator(); 
									
									while(var2.hasNext()) { 
											ImageView var3 = (ImageView)var2.next(); 
											if (var1.getTag().toString().equals(var3.getTag().toString())) { 
													var3.setImageDrawable(getResources().getDrawable(R.drawable.checked_box)); 
													var3.setId(1); 
											} else { 
													var3.setImageDrawable(getResources().getDrawable(R.drawable.unchecked_box)); 
													var3.setId(2); 
											} 
									} 
							} 
							
							return true; 
					} 
			}); 
			var10.setOnClickListener(new OnClickListener() { 
					public void onClick(final View var1) { 
							if (var1.getId() == 0) { 
									PopupMenu var2 = new PopupMenu(getApplicationContext(), var1); 
									var2.getMenu().add("Delete"); 
									var2.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() { 
											public boolean onMenuItemClick(MenuItem var1x) { 
													TranslateAnimation var2 = new TranslateAnimation(0.0F, 0.0F, 0.0F, -200.0F); 
													var2.setDuration(400L); 
													LinearLayout var3 = (LinearLayout)lay_list.get(var1.getTag().toString()); 
													var3.setAnimation(var2); 
													if (var3 != null && var3.getParent() != null) { 
															((ViewGroup)var3.getParent()).removeView(var3); 
													} 
													
													remove(var1.getTag().toString()); 
													return false; 
											} 
									}); 
									var2.show(); 
							} else { 
									if (var1.getId() == 1) { 
											((ImageView)var1).setImageDrawable(getResources().getDrawable(R.drawable.unchecked_box)); 
											var1.setId(2); 
											return; 
									} 
									
									if (var1.getId() == 2) { 
											((ImageView)var1).setImageDrawable(getResources().getDrawable(R.drawable.checked_box)); 
											var1.setId(1); 
											return; 
									} 
							} 
							
					} 
			}); 
	} 
	
	public String byte_to(long bytt) { 
		    
			long kb_ = bytt / 1024L; 
			if (kb_ <= 1024L) { 
					return bytt < 1024L ? bytt + "B" : kb_ + "KB"; 
			} else if (kb_ / 1024L <= 1024L) { 
					String var6 = String.valueOf((float)kb_ / 1024.0F); 
					return var6.substring(var6.indexOf("."), var6.length()).length() >= 3 ? var6.substring(0, 3 + var6.indexOf(".")) + "MB" : var6 + "MB"; 
			} else { 
					String var5 = String.valueOf((float)kb_ / 1024.0F / 1024.0F); 
					return var5.substring(var5.indexOf("."), var5.length()).length() >= 3 ? var5.substring(0, 3 + var5.indexOf(".")) + "GB" : var5 + "GB"; 
			} 
	} 
	
	int indexOf(JSONArray arr, String v) { 
			try{
					int cn = 0; 
					while(true) { 
							if (cn < arr.length() && arr.getString(cn).equals(v)) { 
									return cn; 
							} 
							cn++;
					} 
			}catch(Exception izzuf){
			}
			return -1;
	} 
	
	public void onRequestPermissionsResult(int var1, String[] var2, int[] var3) { 
			super.onRequestPermissionsResult(var1, var2, var3); 
	} 
	
	
	public static int getHeight(Context context) {
				WindowManager windowManager = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
				DisplayMetrics displayMetrics = new DisplayMetrics();
				if (windowManager != null) {
						if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
								context.getDisplay().getRealMetrics(displayMetrics);
						} else {
								windowManager.getDefaultDisplay().getRealMetrics(displayMetrics);
						}
				}
				return displayMetrics.heightPixels;
		}
		
	
	
	void openWith(String var1) { 
			Uri var2 = FileProvider.getUriForFile(this, getPackageName(), new File(var1)); 
			Intent var3 = new Intent(Intent.ACTION_VIEW); 
			var3.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
			var3.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
			var3.setData(var2); 
			startActivity(var3); 
	} 
	
	void remove(String var1) { 
			boolean var10001; 
			try { 
					SharedPreferences var3 = getSharedPreferences("_files_array", 0); 
					JSONArray var4 = new JSONArray(var3.getString("_files", new JSONArray().toString())); 
					int var5 = indexOf(var4, var1); 
					
					if (var5 != -1) { 
							var4.remove(var5); 
					} 
					
					var3.edit().putString("_files", var4.toString()).apply(); 
					if (var4.length() == 0) { 
							linear6.setVisibility(View.VISIBLE); 
					}else{
							linear6.setVisibility(View.GONE); 
					}
			} catch (Exception var9) { 
			} 
	} 
	
	void showBar(boolean var1) { 
			if (var1) { 
					bar_.setVisibility(View.VISIBLE); 
			} else { 
					bar_.setVisibility(View.GONE); 
			} 
	} 
	
	void startGetThum() { 
			new Thread(new Runnable() { 
					public void run() { 
							Iterator mIterator = metaData_list.iterator(); 
							
							while(mIterator.hasNext()) { 
									((metaData)mIterator.next()).start(); 
							} 
							
							metaData_list.clear(); 
					} 
			}).start(); 
	} 
	
	void update() { 
			Exception var10000; 
			label126: { 
					SharedPreferences var2; 
					JSONArray var3; 
					boolean var10001; 
					try { 
							if (!allow_all_Permission(this)) { 
									return; 
							} 
							
							var2 = this.getSharedPreferences("_files_array", 0); 
							var3 = new JSONArray(var2.getString("_files", (new JSONArray()).toString())); 
							linear6.setVisibility(8); 
							if (var3.length() == 0) { 
									linear6.setVisibility(0); 
									return; 
							} 
					} catch (Exception var23) { 
							var10000 = var23; 
							var10001 = false; 
							break label126; 
					} 
					
					int var4 = 0; 
					
					JSONArray var5; 
					while(true) { 
							try { 
									if (var4 >= var3.length()) { 
											var5 = new JSONArray(); 
											break; 
									} 
							} catch (Exception var21) { 
									var10000 = var21; 
									var10001 = false; 
									break label126; 
							} 
							
							label129: { 
									LinearLayout var12; 
									try { 
											String var11 = var3.getString(var4); 
											if ((new File(var11)).exists()) { 
													break label129; 
											} 
											
											var12 = (LinearLayout)this.lay_list.get(var11); 
									} catch (Exception var22) { 
											var10000 = var22; 
											var10001 = false; 
											break label126; 
									} 
									
									if (var12 != null) { 
											try { 
													if (var12.getParent() != null) { 
															((ViewGroup)var12.getParent()).removeView(var12); 
													} 
											} catch (Exception var20) { 
													var10000 = var20; 
													var10001 = false; 
													break label126; 
											} 
									} 
									
									try { 
											var3.put(var4, "null"); 
									} catch (Exception var19) { 
											var10000 = var19; 
											var10001 = false; 
											break label126; 
									} 
							} 
							
							++var4; 
					} 
					
					int var6 = 0; 
					
					while(true) { 
							try { 
									if (var6 >= var3.length()) { 
											break; 
									} 
							} catch (Exception var17) { 
									var10000 = var17; 
									var10001 = false; 
									break label126; 
							} 
							
							try { 
									String var9 = var3.getString(var6); 
									if (!var9.equals("null")) { 
											var5.put(var9); 
									} 
							} catch (Exception var18) { 
									var10000 = var18; 
									var10001 = false; 
									break label126; 
							} 
							
							++var6; 
					} 
					
					int var7 = 0; 
					
					label131: { 
							while(true) { 
									try { 
											if (var7 >= var5.length()) { 
													if (var5.length() != 0) { 
															break; 
													} 
													
													this.linear6.setVisibility(0); 
													break label131; 
											} 
									} catch (Exception var16) { 
											var10000 = var16; 
											var10001 = false; 
											break label126; 
									} 
									
									try { 
											String var8 = var5.getString(var7); 
											if (this.lay_list.get(var8) == null) { 
													this.appendNewVideo(var8); 
											} 
									} catch (Exception var15) { 
											var10000 = var15; 
											var10001 = false; 
											break label126; 
									} 
									
									++var7; 
							} 
							
							try { 
									linear6.setVisibility(8); 
							} catch (Exception var14) { 
									var10000 = var14; 
									var10001 = false; 
									break label126; 
							} 
					} 
					
					try { 
							var2.edit().putString("_files", var5.toString()).apply(); 
							startGetThum(); 
							return; 
					} catch (Exception var13) { 
							var10000 = var13; 
							var10001 = false; 
					} 
			} 
			
			Exception var1 = var10000; 
			showMessage("" + var1); 
	} 
	
	private class DialogBox { 
			private Dialog dialoggm; 
			private MainActivity.DialogClickEvent event; 
			private TextView headTitle; 
			private TextView message; 
			private TextView no; 
			private TextView yes; 
			
			DialogBox() { 
					LinearLayout var2 = (LinearLayout)LayoutInflater.from(MainActivity.this).inflate(R.layout.dialog, (ViewGroup)null); 
					LinearLayout var3 = (LinearLayout)var2.findViewById(R.id.layout0); 
					yes = (TextView)var2.findViewById(R.id.yes); 
					no = (TextView)var2.findViewById(R.id.no); 
					headTitle = (TextView)var2.findViewById(R.id.textview1); 
					message = (TextView)var2.findViewById(R.id.textview2); 
					ViewGroup var4 = (ViewGroup)var3.getParent(); 
					if (var4 != null) { 
							var4.removeView(var3); 
					} 
					
					dialoggm = new Dialog(MainActivity.this); 
					dialoggm.requestWindowFeature(1); 
					dialoggm.setContentView(var3); 
					dialoggm.getWindow().setBackgroundDrawable(new ColorDrawable(0)); 
					dialoggm.getWindow().setGravity(17); 
					WindowManager.LayoutParams var6 = this.dialoggm.getWindow().getAttributes(); 
					var6.height = -2; 
					var6.width = -2; 
					dialoggm.getWindow().setAttributes(var6); 
					dialoggm.getWindow().setDimAmount(0.2F); 
					setup(); 
			} 
			
			private void hide() { 
					dialoggm.dismiss(); 
			} 
			
			private MainActivity.DialogBox setClickEvent(MainActivity.DialogClickEvent var1) { 
					event = var1; 
					return this; 
			} 
			
			private MainActivity.DialogBox setMessage(String var1) { 
					message.setText(var1); 
					return this; 
			} 
			
			private void setup() { 
					yes.setOnClickListener(new OnClickListener() { 
							public void onClick(View var1) { 
									hide(); 
									if (event != null) { 
											event.onYes(); 
									} 
									
							} 
					}); 
					no.setOnClickListener(new OnClickListener() { 
							public void onClick(View var1) { 
									hide(); 
									if (event != null) { 
											event.onCancel(); 
									} 
									
							} 
					}); 
			} 
			
			private void show() { 
					dialoggm.show(); 
			} 
	} 
	
	interface DialogClickEvent { 
			void onCancel(); 
			
			void onYes(); 
	} 
	
	class metaData { 
			ImageView img; 
			Object[] obj = new Object[2]; 
			String path; 
			TextView tm; 
			
			metaData(ImageView var2, TextView var3, String var4) { 
					img = var2; 
					tm = var3; 
					path = var4; 
			} 
			
			void start() { 
					boolean var10001; 
					label62: { 
							MediaMetadataRetriever var2; 
							String var3; 
							label63: { 
									try { 
											if (MainActivity.thm_map.get(path) == null) { 
													var2 = new MediaMetadataRetriever(); 
													var2.setDataSource(path); 
													var3 = var2.extractMetadata(9); 
													break label63; 
											} 
									} catch (Exception var14) { 
											var10001 = false; 
											return; 
									} 
									
									try { 
											obj = (Object[])thm_map.get(path); 
											break label62; 
									} catch (Exception var9) { 
											var10001 = false; 
											return; 
									} 
							} 
							
							if (var3 == null) { 
									var3 = "0"; 
							} 
							
							long var4; 
							ImageView var6; 
							try { 
									var4 = Long.parseLong(var3); 
									var6 = img; 
							} catch (Exception var12) { 
									var10001 = false; 
									return; 
							} 
							
							Bitmap var7 = null; 
							if (var6 != null) { 
									try { 
											var7 = var2.getFrameAtTime(1000L * (var4 / 3L), 2); 
									} catch (Exception var11) { 
											var10001 = false; 
											return; 
									} 
							} 
							
							try { 
									var2.release(); 
									if (img != null) { 
											obj[0] = var7; 
									} 
							} catch (Exception var13) { 
									var10001 = false; 
									return; 
							} 
							
							try { 
									obj[1] = window_service.stoview(var4 / 1000L); 
									MainActivity.thm_map.put(path, obj); 
							} catch (Exception var10) { 
									var10001 = false; 
									return; 
							} 
					} 
					
					try { 
							runOnUiThread(new Runnable() { 
									public void run() { 
											if (obj[0] != null) { 
													img.setImageBitmap((Bitmap)obj[0]); 
													((View)img.getParent()).setBackgroundDrawable(getResources().getDrawable(R.drawable.tmbg)); 
											} else { 
													((View)tm.getParent().getParent()).setBackgroundColor(0); 
											} 
											
											tm.setText((String)obj[1]); 
									} 
							}); 
					} catch (Exception var8) { 
							var10001 = false; 
					} 
			} 
	} 
	
	
	{
			
			
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}