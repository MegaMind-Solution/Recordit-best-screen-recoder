package com.mrc.rcdit;

import android.content.*;
import android.media.projection.MediaProjectionManager;

public class store {
    public static Context context;
    public static Result result;
    public static MediaProjectionManager pmanager;
    public static boolean allowToUseContext = true;
    
    public static void setResultInterface(Result res){
        result = res;
    }
    
    public static Result getResultInterface(){
        return result;
    }
    
    public static void setMediaProjectionManager(MediaProjectionManager mngr){
     pmanager = mngr;
    }
    
    public static MediaProjectionManager getMediaProjectionManager(){
        return pmanager;
    }
    
    public static void setContext(Context cn){
       context = cn;
    }
    
    public static Context getContext(){
        return context;
    }
    
    public static void toAllowUseContext(boolean jh){
        allowToUseContext = jh;
    }
}



