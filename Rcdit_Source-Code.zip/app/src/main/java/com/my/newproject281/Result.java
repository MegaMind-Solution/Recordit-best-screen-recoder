package com.my.newproject281;

import android.content.*;

public interface Result {
    void onResult(int resu_Code, Intent intent);
    void onClickCloseInNotify();
}

