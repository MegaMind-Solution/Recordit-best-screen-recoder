package com.my.newproject281;

import android.app.*;
import android.media.*;
import android.content.*;
import android.os.*;
import java.util.*;
import java.io.*;
import android.view.*;
import android.widget.*;
import android.util.*;
import android.graphics.*;
import android.media.*;
import org.json.JSONArray;
import android.animation.ObjectAnimator;
import android.hardware.display.*;
import android.media.projection.*;
import android.view.animation.TranslateAnimation;
import android.content.res.Resources;
import android.view.animation.Animation;
import android.animation.Animator;

public class window_service extends Service {
	
	private WindowManager.LayoutParams WindParams;
	private WindowManager window;
	private LinearLayout over_back, right_lay, left_lay;
	private ImageView pause_resume, setti, stop, icon_img, close_ovr, setting_btn;
	private FrameLayout icon_;
	private TextView time;
	private boolean swing_controls = true, tch = false;
	private int WDefX, WDefY, screen_w, screen_h;
	private OAnimation anim1, anim2, anim3, anim4, _anim1, _anim2;
	private boolean overly_left = false, overly_right = true;
	private TextView tx_spc;
	private MediaRecorder aMediaRecorder;
	private MediaProjectionManager aMediaProjectionManager;
	private MediaProjection mMediaProjection;
	private VirtualDisplay mVirtualDisplay;
	private SharedPreferences ssppns;
	public static String state_of_recorder = "none";
	private ImageView ichghk;
	private float xhxhhf;
	private boolean close_showing = false, pos_is_close = false;
	private Vibrator mVibrator;
	private MotionEvent mMotionEvent;
	private boolean over_fin_toutch = true, over_fin_toutch2 = false;
	private LinearLayout main_overlay;
	private int noti_res, noti_res2;
	private LinearLayout left_lay_obj, top_lay, bottom_lay;
	
	@Override
	public IBinder onBind(Intent intent) {
		return null;
	}
	
	@Override
	public void onCreate() {
		super.onCreate();
		
		viewNotfication();
		
		ssppns = getSharedPreferences("_data_settings", Context.MODE_PRIVATE);
		screen_h = ssppns.getInt("_device_height", -1);
		screen_w = getWidth(getApplicationContext());
		if(screen_h == -1){
			screen_h = 1280;
			screen_w = 720;
		}
		mVibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
		
		jhff(); 
		
		LinearLayout inflater = (LinearLayout) LayoutInflater.from(this).inflate(R.layout.hgg, null);
		over_back = inflater.findViewById(R.id.linear1);
		if(over_back.getParent() != null){
			((ViewGroup)over_back.getParent()).removeView(over_back);
		}
		right_lay = over_back.findViewById(R.id.right_);
		left_lay = over_back.findViewById(R.id.left_);
		pause_resume = over_back.findViewById(R.id.pause_resume);
		setti = over_back.findViewById(R.id.setti);
		stop = over_back.findViewById(R.id.stop);
		icon_ = over_back.findViewById(R.id.icon_);
		time = over_back.findViewById(R.id.time);
		tx_spc = over_back.findViewById(R.id.tx_spc);
		icon_img = over_back.findViewById(R.id.icon_img);
		left_lay_obj = over_back.findViewById(R.id.left_lay);
		top_lay = over_back.findViewById(R.id.top_lay);
		bottom_lay = over_back.findViewById(R.id.bottom_lay);
		close_ovr = over_back.findViewById(R.id.close_ovr);
		setting_btn = over_back.findViewById(R.id.setti);
		
		window = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
		WindParams = new WindowManager.LayoutParams();
		WindParams.x = 300;
		WindParams.y = 300;	
		WindParams.width = -2;
		WindParams.height = -2;
		WindParams.gravity = Gravity.TOP | Gravity.LEFT;
		WindParams.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL;
		WindParams.type = Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE;
		WindParams.format = PixelFormat.TRANSLUCENT;
		
		back_lay();
		more();
	}
	
	@Override
	public int onStartCommand(Intent intent, int flags, int startId) {
		if(MainActivity.allow_all_Permission(this)){
			if(intent.getAction() != null && intent.getAction().equals("fromReceiver")){
				if(noti_res == R.drawable.hdhr_2){
					if(state_of_recorder.equals("recording")){
						pause();
					}
				}else if(noti_res == R.drawable.hdhr_1){
					if(state_of_recorder.equals("paused")){
						resume();
					} 
				}else if(noti_res == R.drawable.jgh){
					if(state_of_recorder.equals("stoped") || state_of_recorder.equals("none")){
						store.toAllowUseContext(true);
						startNew();
					}
				}
			} 
			else if(intent.getAction() != null && intent.getAction().equals("fromReceiver_Stop..stt")){
				stop();
			}
			else if(state_of_recorder.equals("stoped") || state_of_recorder.equals("none")){
				startNew();
			}
			updateNotify();
		}else{
			Intent inn = new Intent();
			inn.setClass(this, MainActivity.class);
			inn.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
			startActivity(inn);
		}
		return START_STICKY;
	}
	
	@Override
	public void onDestroy() {
		super.onDestroy();
	}
	
	void hideAndShow(boolean hgggg){
		if(hgggg){
			swing_controls = true;
			anim1.show();
			anim2.show();
			anim3.show();
			anim4.show();
			main_overlay.setVisibility(View.VISIBLE);
		}else{
			anim1.hide();
			anim2.hide();
			anim3.hide();
			anim4.hide();
			swing_controls = false;
			main_overlay.setVisibility(View.GONE);
		}
	}
	
	public void more(){
		
		anim1 = new OAnimation(pause_resume);
		anim2 = new OAnimation(setti);
		anim3 = new OAnimation(stop);
		anim4 = new OAnimation(close_ovr);
		
		_anim1 = new OAnimation(icon_).setDuration(100);
		_anim2 = new OAnimation(left_lay_obj).setDuration(100);
		
		over_back.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if(tch){
					if(swing_controls){
						hideAndShow(false);
					}else{
						hideAndShow(true); 
					}
				}
			}
		});
		
		
		setting_btn.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				
				Intent inn = new Intent();
				inn.setClass(getApplicationContext(), SttActivity.class);
				inn.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
				startActivity(inn);
			}
		});
		
		stop.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view) {
				
				if(state_of_recorder.equals("recording") || state_of_recorder.equals("paused")){
					stop();
				}else if(state_of_recorder.equals("stoped")){
					Intent inn = new Intent();
					inn.setClass(getApplicationContext(), MainActivity.class);
					inn.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
					startActivity(inn);
				}
			}
		});
		
		pause_resume.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view) {
				if(state_of_recorder.equals("recording")){
					pause();
				}else if(state_of_recorder.equals("paused")){
					resume();
				}else if(state_of_recorder.equals("stoped")){
					startNew();
				}
				updateNotify();
			}
		});
		
		
		over_back.setOnTouchListener(new View.OnTouchListener(){
			@Override
			public boolean onTouch(View view, MotionEvent me){
				mMotionEvent = me;
				if(me.getPointerCount() == 1){
					if(me.getAction() == MotionEvent.ACTION_DOWN){
						int h = WindParams.y;
						int w = WindParams.x;
						
						int WTX = (int)me.getRawX();
						int WTY = (int)me.getRawY();
						
						WDefX = WTX - w;
						WDefY = WTY - h;
						
						tch = true;
						
						over_lay_view(true);
						startToutchCal();
						over_fin_toutch = true;
						over_fin_toutch2 = true;
					} 
					else if(me.getAction() == MotionEvent.ACTION_MOVE)
					{  
						tch = false;
						int WRx = (int)me.getRawX();
						int WRy = (int)me.getRawY();
						
						WindParams.x = WRx - WDefX;
						WindParams.y = WRy - WDefY;
						
						over_back.setLayoutParams(WindParams);
						window.updateViewLayout(over_back, WindParams);
						
						if(state_of_recorder.equals("recording") || state_of_recorder.equals("paused")){
							if(me.getRawY() > screen_h / 2){
								//when not showing
								if(!jhggghf){
									showCloseButton();
								}
							}else{
								if(jhggghf){
									hideCloseButton();
								} 
							}
						}else{
							if(over_fin_toutch){
								over_fin_toutch = false;
								if(!jhggghf){
									showCloseButton();
								}
							}
						}
					}
					if(WindParams.x < over_back.getWidth()){
						if(overly_right){
							overlay_icon_setLeft();
						}
					}else if(screen_w - over_back.getWidth() < WindParams.x){
						if(overly_left){
							overlay_icon_setRight(); 
						}
					}
					
					int[] jgzfzf = new int[2];
					ichghk.getLocationOnScreen(jgzfzf);
					
					int appX = (int)me.getRawX(), 
					appY = (int)me.getRawY(),
					minOpX = jgzfzf[0],
					minOpY = jgzfzf[1],
					maxOpX = minOpX + ichghk.getWidth(),
					maxOpY = minOpY + ichghk.getHeight();
					if(minOpX < appX && appX < maxOpX && maxOpY > appY && appY > minOpY){
						ichghk.setImageResource(R.drawable.hggz);
						pos_is_close = true;
						gggufff = true;
						vibrate(100);
					}else{
						ichghk.setImageResource(R.drawable.ccl_2);
						pos_is_close = false;
					}
					
					if(me.getAction() == MotionEvent.ACTION_UP){
						over_fin_toutch = false;
						toutchOut();
					}
					
				}
				return false;
			}
		});
		
	}
	
	void pause(){
		state_of_recorder = "paused";
		pause_resume.setImageResource(R.drawable.hdhr_1);
		startTimer(false);
		aMediaRecorder.pause();
	}
	
	void resume(){
		state_of_recorder = "recording";
		pause_resume.setImageResource(R.drawable.hdhr_2);
		startTimer(true);
		aMediaRecorder.resume();
	}
	
	void startNew(){
		if(ssppns.getBoolean("_record_screen", true)){
			SActivity.set(true);
			Intent inn = new Intent();
			inn.setClass(getApplicationContext(), SActivity.class);
			inn.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
			startActivity(inn);
		}else{
			createRecorder();
			showOverlay();
			startRecord();
		}
	}
	
	void stop(){
		stop.setImageResource(R.drawable.hhh_1);
		pause_resume.setImageResource(R.drawable.jgh);
		icon_img.setImageResource(R.drawable.uduf);
		time.setVisibility(View.GONE);
		state_of_recorder = "stoped";
		stopRecord();
	}
	
	void removeOverly(){
		if(over_back.getParent() != null){
			try{
				window.removeViewImmediate(over_back);
			}catch(Exception hgg){
			}
		}
	}
	
	private void showOverlay(){
		try{ 
			if(over_back.getParent() != null){
				try{
					window.removeViewImmediate(over_back);
				}catch(Exception hgg){
				}
			}
			window.addView(over_back, WindParams);
		}catch(Exception e){
		}
		
	}
	
	class OAnimation{
		ObjectAnimator DCanimX;
		ObjectAnimator DCanimY;
		View v;
		
		OAnimation(View vw){
			v = vw;
			DCanimX = new ObjectAnimator();
			DCanimX.setTarget(vw);
			DCanimX.setPropertyName("scaleX");
			DCanimX.setDuration(500);
			
			DCanimY = new ObjectAnimator();
			DCanimY.setTarget(vw);
			DCanimY.setPropertyName("scaleY");
			DCanimY.setDuration(500);
		}
		
		void show(){
			
			v.animate()
			.setDuration(500)
			.rotationBy(360)
			.start();
			
			justShow();
			top_lay.setVisibility(View.VISIBLE);
			bottom_lay.setVisibility(View.VISIBLE);
			left_lay_obj.setVisibility(View.VISIBLE);
			tx_spc.setVisibility(View.VISIBLE);
		}
		
		void hide(){
			
			v.animate()
			.setDuration(500)
			.rotationBy(-360)
			.start();
			
			justHide();
			TimerTask gg = new TimerTask() {
				@Override
				public void run(){
					Handler handler = new Handler(Looper.getMainLooper());
					handler.post(new Runnable() {
						@Override
						public void run() {
							top_lay.setVisibility(View.GONE);
							bottom_lay.setVisibility(View.GONE);
							left_lay_obj.setVisibility(View.GONE);
							tx_spc.setVisibility(View.GONE);
						}
					});  
				}
			};
			new Timer().schedule(gg, 500);
		}
		
		void justHide(){
			start(1.0f, 0f);
		}
		
		void justShow(){
			start(0f, 1.0f);
		}
		
		void start(float a, float b){
			DCanimY.setFloatValues(a, b);
			DCanimX.setFloatValues(a, b);  
			DCanimY.start(); 
			DCanimX.start();
		}
		
		ObjectAnimator getMainAnimator(){
			return DCanimY;
		}
		
		OAnimation setDuration(int ms){
			DCanimX.setDuration(ms);
			DCanimY.setDuration(ms);
			return this;
		}
		
	}
	
	void remove_over_btn_prnt(){
		ViewGroup hhf = (ViewGroup) icon_.getParent();
		if(hhf != null){
			hhf.removeView(icon_); 
		}
		hhf = (ViewGroup) left_lay_obj.getParent();
		if(hhf != null){
			hhf.removeView(left_lay_obj); 
		}
	}
	
	void overlay_icon_setLeft(){
		overly_left = true;
		overly_right = false;
		remove_over_btn_prnt();
		left_lay.addView(icon_);
		right_lay.addView(left_lay_obj);
		changing_anim();
		bottom_lay.setGravity(Gravity.CENTER | Gravity.LEFT);
		top_lay.setGravity(Gravity.CENTER | Gravity.LEFT);
	}
	
	void overlay_icon_setRight(){
		overly_left = false;
		overly_right = true;
		remove_over_btn_prnt();
		left_lay.addView(left_lay_obj);
		right_lay.addView(icon_);
		changing_anim();
		bottom_lay.setGravity(Gravity.CENTER | Gravity.RIGHT);
		top_lay.setGravity(Gravity.CENTER | Gravity.RIGHT);
	}
	
	void changing_anim(){
		_anim1.justHide();
		_anim2.justHide();
		
		TimerTask hehh = new TimerTask() {
			@Override
			public void run(){
				Handler handler = new Handler(Looper.getMainLooper());
				handler.post(new Runnable() {
					@Override
					public void run() {
						_anim1.justShow();
						_anim2.justShow();
					}
				});  
			}
		};
		new Timer().schedule(hehh, 200);
	}
	
	String out_path;
	void createRecorder(){
		
		try{
			
			String out_format = ssppns.getString("_out_formate", "MPEG-4");
			String fileExt = ".mp4";
			
			int output_f = -1;
			int v_f = -1;
			int a_f = -1;
			
			switch (out_format) {
				case "3gp":
				output_f = MediaRecorder.OutputFormat.THREE_GPP;
				v_f = MediaRecorder.VideoEncoder.H263;
				a_f = MediaRecorder.AudioEncoder.AMR_NB;
				break;
				case "MPEG-4":
				output_f = MediaRecorder.OutputFormat.MPEG_4;
				v_f = MediaRecorder.VideoEncoder.H264;
				a_f = MediaRecorder.AudioEncoder.AAC;
				break;
				case "Webm":
				output_f = MediaRecorder.OutputFormat.WEBM;
				v_f = MediaRecorder.VideoEncoder.VP8;
				a_f = Build.VERSION.SDK_INT >= 29 ? MediaRecorder.AudioEncoder.OPUS : MediaRecorder.AudioEncoder.AAC;
				break;
				case "MPEG-2":
				output_f = Build.VERSION.SDK_INT >= 26 ? MediaRecorder.OutputFormat.MPEG_2_TS : MediaRecorder.OutputFormat.MPEG_4;
				v_f = MediaRecorder.VideoEncoder.H264;
				a_f = MediaRecorder.AudioEncoder.AAC;
				break;
			}
			
			aMediaRecorder = new MediaRecorder();
			
			boolean avai = isMicrophoneAvailable();
			
			if(avai){
				if(ssppns.getBoolean("_use_mic", true)){
					aMediaRecorder.setAudioSource(MediaRecorder.AudioSource.MIC);
				}
			}
			if(ssppns.getBoolean("_record_screen", true)){
				aMediaRecorder.setVideoSource(MediaRecorder.VideoSource.SURFACE);
			}
			aMediaRecorder.setOutputFormat(output_f);
			if(avai){
				if(ssppns.getBoolean("_use_mic", true)){
					aMediaRecorder.setAudioEncoder(a_f);
					fileExt = ".mp3";
				}
			}
			if(ssppns.getBoolean("_record_screen", true)){
				aMediaRecorder.setVideoEncoder(v_f);
				aMediaRecorder.setVideoSize(ssppns.getInt("_width", screen_w), ssppns.getInt("_height", screen_h));
				aMediaRecorder.setVideoEncodingBitRate(ssppns.getInt("_qua_rate", 10485760));//10_megabyte
				aMediaRecorder.setVideoFrameRate(ssppns.getInt("_fps", 30));
				if(out_format.equals("3gp")){
					fileExt = ".3gp";
				}else{
					fileExt = ".mp4";
				}
			}
			
			out_path = Environment.getExternalStorageDirectory()+"/Recordit/";
			File fl = new File(out_path);
			if(!fl.exists()){
				fl.mkdir();
			}
			
			out_path += "Recordit_MRc-"+System.currentTimeMillis()+fileExt;
			aMediaRecorder.setOutputFile(out_path);
			
			aMediaRecorder.prepare();
			
		}catch(Exception hggg){
			Toast.makeText(getApplicationContext(), hggg+"#####", 0).show();
		}
		
	}
	
	
	RemoteViews mRemoteViews;
	private RemoteViews getReView(){
		mRemoteViews = new RemoteViews(getPackageName(), R.layout.notification);
		int flg = PendingIntent.FLAG_UPDATE_CURRENT;
		
		Intent inrecord = new Intent(this, notiBrodcast.class);
		inrecord.putExtra("record", "record");
		Intent insettings = new Intent(this, notiBrodcast.class);
		insettings.putExtra("settings", "settings");
		Intent inhome = new Intent(this, notiBrodcast.class);
		inhome.putExtra("home", "home");
		Intent intcls = new Intent(this, notiBrodcast.class);
		intcls.putExtra("close", "close");
		
		
		PendingIntent penRecord = PendingIntent.getBroadcast(this, 1001, inrecord, flg);
		PendingIntent penSettings = PendingIntent.getBroadcast(this, 2002, insettings, flg);
		PendingIntent penHome = PendingIntent.getBroadcast(this, 3003, inhome, flg);
		PendingIntent penClose = PendingIntent.getBroadcast(this, 4004, intcls, flg);
		
		mRemoteViews.setOnClickPendingIntent(R.id.record, penRecord);
		mRemoteViews.setOnClickPendingIntent(R.id.settings, penSettings);
		mRemoteViews.setOnClickPendingIntent(R.id.home, penHome);
		mRemoteViews.setOnClickPendingIntent(R.id.close,penClose);
		
		return mRemoteViews;
	}
	
	Notification notification;
	NotificationManager NManager;
	void viewNotfication(){
		
		NManager = getSystemService(NotificationManager.class);
		
		createCnl();
		
		Notification.Builder nb = new Notification.Builder(this)
		.setContent(getReView())
		.setSmallIcon(R.drawable.trn)
		.setOnlyAlertOnce(true);
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
			nb.setChannelId("ss_recorder");
		}
		notification = nb.build();
		
		startForeground(2005, notification);
	}
	
	void createCnl(){
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
			NotificationChannel serviceChannel = new NotificationChannel(
			"ss_recorder",
			"Foreground Service Channel test",
			NotificationManager.IMPORTANCE_DEFAULT);
			NManager.createNotificationChannel(serviceChannel);
		}
	}
	
	void jhff(){
		aMediaProjectionManager = (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
		store.setMediaProjectionManager(aMediaProjectionManager);
		ev();
	}
	
	void ev(){
		Result rsl = new Result(){
			public void onResult(int resu_Code, Intent intent){
				if(Activity.RESULT_OK == resu_Code){
					createRecorder();
					mMediaProjection = aMediaProjectionManager.getMediaProjection(resu_Code, intent);
					mVirtualDisplay = mMediaProjection.createVirtualDisplay("window_service", ssppns.getInt("_width", screen_w), ssppns.getInt("_height", screen_h),  getDpi(getApplicationContext()), DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, aMediaRecorder.getSurface(), null, null);
					showOverlay();
					startRecord();
				}
			}
			
			public void onClickCloseInNotify(){
				close(); 
				stopForeground(true);
				stopSelf();
				NManager.cancel(2005);
			}
			
		}; 
		store.setResultInterface(rsl);
		
	}
	
	void startRecord(){
		timetr = 0;
		time.setText("00:00");
		state_of_recorder = "recording";
		pause_resume.setImageResource(R.drawable.hdhr_2);
		stop.setImageResource(R.drawable.hgg);
		icon_img.setImageResource(R.drawable.hdhr_5);
		time.setVisibility(View.VISIBLE);
		aMediaRecorder.start();
		startTimer(true);
		over_lay_view(false);
		if(swing_controls){
			main_overlay.setVisibility(View.VISIBLE);
		}
		updateNotify();
	}
	
	public static int getWidth(Context cn){
		return cn.getResources().getDisplayMetrics().widthPixels;   
	}
	
	
	public static int getLHeight(Context cn){
		return cn.getResources().getDisplayMetrics().heightPixels;   
	}
	
	public static int getDpi(Context cn){
		return cn.getResources().getDisplayMetrics().densityDpi;
	}
	
	public float getDensity(){
		return getResources().getDisplayMetrics().density;
	}
	
	
	private TimerTask tmprf;
	private int timetr = 0;
	private void startTimer(final boolean ena){
		
		try{
			if(tmprf != null){
				tmprf.cancel();
			}
			if(ena){
				tmprf = new TimerTask() {
					@Override
					public void run() {
						Handler handler = new Handler(Looper.getMainLooper());
						handler.post(new Runnable() {
							@Override
							public void run() {
								timetr++;
								time.setText(stoview(timetr));
							} 
						});
					}
				};
				new Timer().scheduleAtFixedRate(tmprf, 1000, 1000);
			}else{
				if(tmprf != null){
					tmprf.cancel();
				}
			}
		}catch(Exception hgg){
		}
	}
	
	void stopRecord(){
		try{
			if(aMediaRecorder != null){
				aMediaRecorder.stop();
				aMediaRecorder.reset();
				aMediaRecorder.release(); 
			}
			if(mVirtualDisplay != null){
				mVirtualDisplay.release();
			}
			if(mMediaProjection != null){
				mMediaProjection.stop();
			}
			if(tmprf != null){
				tmprf.cancel();
			}
			
			SharedPreferences sp = getSharedPreferences("_files_array", Context.MODE_PRIVATE);
			JSONArray dt = new JSONArray(sp.getString("_files", new JSONArray().toString()));
			sp.edit().putString("_files", dt.put(out_path).toString()).apply();
			if(mListener != null){
				mListener.onStop();
			}
			startEndAnim();
			updateNotify();
			MediaScannerConnection.scanFile(this, new String[]{out_path}, null, null);
		}catch(Exception uhg){
		}
	}
	
	public static String stoview(long s){
		long o_s = 0;
		long o_m = 0;
		long o_h = 0;
		if(s >= 60){
			long m = s / 60;
			o_s = s % 60;
			if(m >= 60){
				o_h = m / 60;   
				o_m = m % m;
			}else{
				o_m = m;
			}
		}else{
			o_s = s; 
		}
		String time = "";
		if((o_m+"").length() == 1){
			time = "0";  
		} 
		time += o_m+":";  
		if((o_s+"").length() == 1){
			time += "0";  
		} 
		time += o_s;
		if(o_h != 0){
			String h = "";
			if((o_h+"").length() == 1){
				h = "0"; 
			} 
			h = o_h+":";
			time = h + time;
		}
		return time;
	}  
	
	LinearLayout llay;
	private void back_lay(){
		
		WindowManager.LayoutParams prm0 = new WindowManager.LayoutParams();
		prm0.x = 0;
		prm0.y = 0;	
		prm0.width = -1;
		prm0.height = screen_h;
		prm0.gravity = Gravity.TOP | Gravity.CENTER;
		prm0.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS;
		prm0.type = Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE;
		prm0.format = PixelFormat.TRANSLUCENT;
		
		main_overlay = new LinearLayout(getApplicationContext());
		main_overlay.setGravity(Gravity.BOTTOM | Gravity.CENTER);
		main_overlay.setOrientation(LinearLayout.VERTICAL);
		main_overlay.setBackgroundColor(Color.argb(120, Color.red(Color.BLACK), Color.green(Color.BLACK), Color.blue(Color.BLACK)));
		main_overlay.setVisibility(View.GONE);
		main_overlay.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				hideAndShow(false);
			}
		});
		
		
		llay = new LinearLayout(getApplicationContext());
		llay.setGravity(Gravity.BOTTOM | Gravity.CENTER);
		llay.setOrientation(LinearLayout.VERTICAL);
		
		ichghk = new ImageView(getApplicationContext());
		ichghk.setImageResource(R.drawable.ccl_2);
		ichghk.setLayoutParams(new LinearLayout.LayoutParams((int)(getDensity()*50), (int)(getDensity()*50)));
		
		llay.addView(ichghk);
		window.addView(main_overlay, prm0);
		
		
		prm0.width = -2;
		prm0.height = screen_h/5;
		prm0.gravity = Gravity.BOTTOM | Gravity.CENTER;
		
		
		window.addView(llay, prm0);
		llay.setVisibility(View.GONE);
	}
	
	
	void showCloseButton(){
		if(!hfzffu_bsy){
			jhggghf = true;
			hfzffu_bsy = true;
			llay.setVisibility(View.VISIBLE);
			ichghk.animate()
			.setDuration(400)
			.translationY(~(screen_h /5-ichghk.getHeight()))
			.start();
		}
	}
	
	boolean jhggghf = false, hfzffu_bsy;
	void hideCloseButton(){
		jhggghf = false;
		ichghk.animate()
		.setDuration(400)
		.translationY((screen_h /5-ichghk.getHeight()))
		.setListener(new Animator.AnimatorListener(){
			public void onAnimationEnd(Animator a){
				hfzffu_bsy = false;
				if(jhggghf == false){
					llay.setVisibility(View.GONE); 
				}
			}
			public void onAnimationCancel(Animator a){}
			public void onAnimationStart(Animator a){}
			public void onAnimationRepeat(Animator a){}
		}).start();
	}
	
	
	
	boolean gggufff = false;
	void vibrate(long ms){
		if(gggufff){
			gggufff = false;
			mVibrator.vibrate(ms);
		}
	}
	
	TimerTask dhhdhd;
	void over_lay_view(boolean fuzf){
		
		if(dhhdhd != null){
			dhhdhd.cancel();
		}
		
		overlyAlpha(true);
		if(!fuzf){
			dhhdhd = new TimerTask() {
				@Override
				public void run() {
					Handler handler = new Handler(Looper.getMainLooper());
					handler.post(new Runnable() {
						@Override
						public void run() {
							overlyAlpha(false);
						} 
					});
				}
			};
			new Timer().schedule(dhhdhd, 5000);
		}
	}
	
	void overlyAlpha(boolean show){
		if(show){
			new OAnimation(icon_).start(0.9f, 1.0f);
			icon_.animate()
			.setDuration(500)
			.alpha(1.0f)
			.start();
		}else{
			new OAnimation(icon_).start(1.0f, 0.9f); 
			icon_.animate()
			.setDuration(500)
			.alpha(0.7f)
			.start();
			if(swing_controls){
				hideAndShow(false);
			}
		}
	}
	
	TimerTask fhhfjg;
	void startToutchCal(){
		if(fhhfjg != null){
			fhhfjg.cancel();
		}
		fhhfjg = new TimerTask() {
			@Override
			public void run() {
				Handler handler = new Handler(Looper.getMainLooper());
				handler.post(new Runnable() {
					@Override
					public void run() {
						if(mMotionEvent.getAction() == MotionEvent.ACTION_UP && over_fin_toutch){
							toutchOut();
						}
					} 
				});
			}
		};
		new Timer().scheduleAtFixedRate(fhhfjg, 0, 100);
	}
	
	void toutchOut(){
		hideCloseButton();
		over_lay_view(false);
		if(pos_is_close){
			close();
		}
	}
	
	void close(){
		if(state_of_recorder.equals("recording") || state_of_recorder.equals("paused")){
			state_of_recorder = "none";
			stopRecord();
		}
		removeOverly();
		main_overlay.setVisibility(View.GONE);
	}
	
	void updateNotify(){
		if(state_of_recorder.equals("recording")){
			noti_res = R.drawable.hdhr_2;
			mRemoteViews.setTextViewText(R.id.textview6, "Pause");
		}else if(state_of_recorder.equals("stoped")){
			noti_res = R.drawable.jgh;
			mRemoteViews.setTextViewText(R.id.textview6, "Record");
		}else if(state_of_recorder.equals("paused")){
			noti_res = R.drawable.hdhr_1;
			mRemoteViews.setTextViewText(R.id.textview6, "Resume");
		}
		else if(state_of_recorder.equals("none")){
			noti_res = R.drawable.jgh;
			mRemoteViews.setTextViewText(R.id.textview6, "Record");
		}
		if(state_of_recorder.equals("paused") || state_of_recorder.equals("recording")){
			noti_res2 = R.drawable.hgg;
			mRemoteViews.setTextViewText(R.id.textview7, "Stop");
		}else{
			noti_res2 = R.drawable.hhh_2;
			mRemoteViews.setTextViewText(R.id.textview7, "Settings");
		}
		mRemoteViews.setImageViewResource(R.id.imageview2, noti_res2); 
		mRemoteViews.setImageViewResource(R.id.imageview1, noti_res);
		NManager.notify(2005, notification);
	}
	
	static Listener mListener;
	public static void setListener(Listener ls){
		mListener = ls;
	}
	
	public interface Listener{
		void onStop();
	}
	
	void startEndAnim(){
		try{
			
			MediaMetadataRetriever retriever = new MediaMetadataRetriever();  
			retriever.setDataSource(out_path);
			String hfuftfh = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);
			if(hfuftfh == null){
				hfuftfh = "0";
			}
			long durationMs = Long.parseLong(hfuftfh);
			final Bitmap image = roundBitmap(retriever.getFrameAtTime(durationMs/2*1000, MediaMetadataRetriever.OPTION_CLOSEST_SYNC));
			retriever.release();
			
			final ImageView hgggg = new ImageView(this);
			hgggg.setImageBitmap(image);
			
			FrameLayout.LayoutParams uzzh = new FrameLayout.LayoutParams(-1,-1);
			uzzh.gravity = Gravity.CENTER;
			
			final LinearLayout layo00 = new LinearLayout(this);
			layo00.setBackgroundColor(Color.argb(90, Color.red(Color.BLACK), Color.green(Color.BLACK), Color.blue(Color.BLACK)));
			layo00.addView(hgggg, uzzh);
			
			WindowManager.LayoutParams prm0 = new WindowManager.LayoutParams();
			prm0.x = 0;
			prm0.y = 0;	
			prm0.width = -1;
			prm0.height = -1;
			prm0.gravity = Gravity.TOP | Gravity.CENTER;
			prm0.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS;
			prm0.type = Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE;
			prm0.format = PixelFormat.TRANSLUCENT;
			
			window.addView(layo00, prm0);
			
			OAnimation anima_ = new OAnimation(hgggg).setDuration(700);
			anima_.getMainAnimator().addListener(new Animator.AnimatorListener() {
				@Override
				public void onAnimationStart(Animator a) {
				}
				@Override
				public void onAnimationEnd(Animator a) {
					try{
						window.removeViewImmediate(layo00);
						hgggg.setImageBitmap(null);
						image.recycle();
					}catch(Exception hgt){
					}
				}
				@Override
				public void onAnimationCancel(Animator a) {
				}
				@Override
				public void onAnimationRepeat(Animator a) {
				}
			});
			anima_.start(1, 0.1f);
		}catch(Exception iffu){
		}
	}
	
	
	Bitmap roundBitmap(Bitmap bits){
		
		int width = bits.getWidth();
		int height = bits.getHeight();
		Bitmap b = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
		Paint paint = new Paint();
		paint.setAntiAlias(true);
		paint.setShader(new BitmapShader(bits, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP));
		Canvas canvas = new Canvas(b);
		canvas.drawRoundRect(new RectF(0, 0, width, height), 50, 50, paint);
		
		bits.recycle();
		
		return b;
	}
	
	
	boolean isMicrophoneAvailable() {
		AudioRecord audioRecord = null;
		try {
			int sampleRate = 44100;
			int bufferSize = AudioRecord.getMinBufferSize(sampleRate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);
			
			audioRecord = new AudioRecord(
			MediaRecorder.AudioSource.MIC, sampleRate,
			AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, bufferSize
			);
			
			if (audioRecord.getState() != AudioRecord.STATE_INITIALIZED) {
				return false;
			} else {
				audioRecord.startRecording();
				boolean isRecording = audioRecord.getRecordingState() == AudioRecord.RECORDSTATE_RECORDING;
				audioRecord.stop();
				return isRecording;
			}
		} catch (Exception e) {
			return false;
		} finally {
			if (audioRecord != null) {
				audioRecord.release();
			}
		}
		
	}
	
	
	
}
