package com.my.newproject281;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.widget.Toast;

public class notiBrodcast extends BroadcastReceiver {
	
	@Override
	public void onReceive(Context context, Intent intent) {
		try{
			if(intent.getStringExtra("record") != null){
				Intent intn = new Intent();
				intn.setAction("fromReceiver");
				intn.setClass(context, window_service.class);
				context.startService(intn);
			}else if(intent.getStringExtra("settings") != null){
				if(window_service.state_of_recorder.equals("recording") || window_service.state_of_recorder.equals("paused")){
					Intent intn = new Intent();
					intn.setAction("fromReceiver_Stop..stt");
					intn.setClass(context, window_service.class);
					context.startService(intn);
				}else{
					Intent inn = new Intent();
					inn.setClass(context, SttActivity.class);
					inn.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
					context.startActivity(inn);
				}
			}else if(intent.getStringExtra("home") != null){
				Intent inn = new Intent();
				inn.setClass(context, MainActivity.class);
				inn.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
				context.startActivity(inn);
			}else if(intent.getStringExtra("close") != null){
				if(store.getResultInterface() != null){
					store.getResultInterface().onClickCloseInNotify();
				}
			}
			if(intent.getStringExtra("close") == null){
				context.sendBroadcast(new Intent(Intent.ACTION_CLOSE_SYSTEM_DIALOGS));
			}
		}catch(Exception hff){
		}
	}
	
	
}
