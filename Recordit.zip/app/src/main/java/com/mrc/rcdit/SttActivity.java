package com.mrc.rcdit;

import android.animation.*;
import android.app.*;
import android.content.*;
import android.content.Intent;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.os.Bundle;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.*;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import java.io.*;
import java.io.InputStream;
import java.text.*;
import java.util.*;
import java.util.regex.*;
import org.json.*;

public class SttActivity extends AppCompatActivity {
	
	private LinearLayout linear1;
	private LinearLayout linear10;
	private ImageView imageview1;
	private TextView textview1;
	private TextView textview17;
	private LinearLayout lineinf;
	private ImageView imageview14;
	private LinearLayout linear2;
	private LinearLayout linear3;
	private LinearLayout linear4;
	private LinearLayout linear11;
	private LinearLayout linear5;
	private LinearLayout linear6;
	private LinearLayout linear12;
	private ImageView imageview7;
	private LinearLayout linear7;
	private TextView textview8;
	private TextView rrv;
	private ImageView imageview2;
	private TextView textview2;
	private TextView textview5;
	private ImageView imageview8;
	private LinearLayout linear8;
	private TextView textview9;
	private TextView qrv;
	private ImageView imageview6;
	private TextView textview3;
	private TextView textview6;
	private ImageView imageview9;
	private LinearLayout linear9;
	private TextView textview10;
	private TextView frv;
	private ImageView imageview5;
	private TextView textview4;
	private TextView textview7;
	private ImageView imageview12;
	private TextView textview11;
	private TextView textview12;
	private TextView textview13;
	private ImageView imageview13;
	private ImageView imageview10;
	private TextView textview14;
	private Switch switch1;
	private ImageView imageview11;
	private TextView textview15;
	private Switch switch2;
	private TextView textview19;
	private ImageView mrc;
	
	private Intent hom = new Intent();
	private Intent inf = new Intent();
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.stt);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		linear1 = findViewById(R.id.linear1);
		linear10 = findViewById(R.id.linear10);
		imageview1 = findViewById(R.id.imageview1);
		textview1 = findViewById(R.id.textview1);
		textview17 = findViewById(R.id.textview17);
		lineinf = findViewById(R.id.lineinf);
		imageview14 = findViewById(R.id.imageview14);
		linear2 = findViewById(R.id.linear2);
		linear3 = findViewById(R.id.linear3);
		linear4 = findViewById(R.id.linear4);
		linear11 = findViewById(R.id.linear11);
		linear5 = findViewById(R.id.linear5);
		linear6 = findViewById(R.id.linear6);
		linear12 = findViewById(R.id.linear12);
		imageview7 = findViewById(R.id.imageview7);
		linear7 = findViewById(R.id.linear7);
		textview8 = findViewById(R.id.textview8);
		rrv = findViewById(R.id.rrv);
		imageview2 = findViewById(R.id.imageview2);
		textview2 = findViewById(R.id.textview2);
		textview5 = findViewById(R.id.textview5);
		imageview8 = findViewById(R.id.imageview8);
		linear8 = findViewById(R.id.linear8);
		textview9 = findViewById(R.id.textview9);
		qrv = findViewById(R.id.qrv);
		imageview6 = findViewById(R.id.imageview6);
		textview3 = findViewById(R.id.textview3);
		textview6 = findViewById(R.id.textview6);
		imageview9 = findViewById(R.id.imageview9);
		linear9 = findViewById(R.id.linear9);
		textview10 = findViewById(R.id.textview10);
		frv = findViewById(R.id.frv);
		imageview5 = findViewById(R.id.imageview5);
		textview4 = findViewById(R.id.textview4);
		textview7 = findViewById(R.id.textview7);
		imageview12 = findViewById(R.id.imageview12);
		textview11 = findViewById(R.id.textview11);
		textview12 = findViewById(R.id.textview12);
		textview13 = findViewById(R.id.textview13);
		imageview13 = findViewById(R.id.imageview13);
		imageview10 = findViewById(R.id.imageview10);
		textview14 = findViewById(R.id.textview14);
		switch1 = findViewById(R.id.switch1);
		imageview11 = findViewById(R.id.imageview11);
		textview15 = findViewById(R.id.textview15);
		switch2 = findViewById(R.id.switch2);
		textview19 = findViewById(R.id.textview19);
		mrc = findViewById(R.id.mrc);
		
		imageview1.setOnLongClickListener(new View.OnLongClickListener() {
			@Override
			public boolean onLongClick(View _view) {
				SketchwareUtil.showMessage(getApplicationContext(), "Go Back!");
				return true;
			}
		});
		
		imageview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				finish();
			}
		});
		
		textview1.setOnLongClickListener(new View.OnLongClickListener() {
			@Override
			public boolean onLongClick(View _view) {
				SketchwareUtil.showMessage(getApplicationContext(), "Settings!");
				return true;
			}
		});
		
		lineinf.setOnLongClickListener(new View.OnLongClickListener() {
			@Override
			public boolean onLongClick(View _view) {
				SketchwareUtil.showMessage(getApplicationContext(), "About Us!");
				return true;
			}
		});
		
		lineinf.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				inf.setClass(getApplicationContext(), InfoActivity.class);
				startActivity(inf);
			}
		});
		
		linear2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				
				dialog_resolu.showPopup();
			}
		});
		
		linear3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				
				    dialog_qua.showPopup();
				    
			}
		});
		
		linear4.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				
				    dialog_fps.showPopup();
				    
			}
		});
		
		linear11.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				dialog_format.showPopup();
			}
		});
		
		linear5.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				
				 if(switch1.isChecked()){
					    switch1.setChecked(false);
					 }else{
					     switch1.setChecked(true);
					 }
			}
		});
		
		linear6.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				
				 if(switch2.isChecked()){
					    switch2.setChecked(false);
					 }else{
					     switch2.setChecked(true);
					 }
			}
		});
		
		switch1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton _param1, boolean _param2) {
				final boolean _isChecked = _param2;
				
				if(!switch2.isChecked() && !switch1.isChecked()){
					    switch2.setChecked(true);
				}
				
				
				ssppns.edit().putBoolean("_use_mic", switch1.isChecked()).apply();
			}
		});
		
		switch2.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton _param1, boolean _param2) {
				final boolean _isChecked = _param2;
				
				if(!switch2.isChecked() && !switch1.isChecked()){
					    switch1.setChecked(true);
				}
				
				
				ssppns.edit().putBoolean("_record_screen", switch2.isChecked()).apply();
			}
		});
		
		mrc.setOnLongClickListener(new View.OnLongClickListener() {
			@Override
			public boolean onLongClick(View _view) {
				SketchwareUtil.CustomToast(getApplicationContext(), "By MicroResearch Corpration", 0xFF9C27B0, 18, 0xFFFFFFFF, 25, SketchwareUtil.BOTTOM);
				inf.setClass(getApplicationContext(), InfoActivity.class);
				startActivity(inf);
				return true;
			}
		});
	}
	
	private void initializeLogic() {
		getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
		init();
		
		GradientDrawable vaggght = new GradientDrawable();
		vaggght.setColor(0xFFFFFFFF);
		linear1.setBackground(vaggght);
		linear1.setElevation(5);
	}
	
	public void _v() {
	}
	
	
	private ListDialog dialog_resolu, dialog_qua, dialog_fps, dialog_format;
	private SharedPreferences ssppns;
	
	void init(){
		    
		   ssppns = getSharedPreferences("_data_settings", Context.MODE_PRIVATE);
		        //SharedPreferences.Editor editor = sharedPreferences.edit();
		        //editor.putString(KEY_USER_NAME, userName);
		        //editor.apply();
		    
		
		    
			final ArrayList<String> list1 = new ArrayList();
			list1.add(getWidth()+"*"+getHeight());
			list1.add("720*1080");
			list1.add("480*800");
			
		    final ArrayList<int[]> list1_v = new ArrayList();
			list1_v.add(new int[]{getWidth(), getHeight()});
			list1_v.add(new int[]{720,1080});
			list1_v.add(new int[]{480,800});
			
		    
			dialog_resolu = new ListDialog(list1);
			dialog_resolu.setAnchor(imageview2);
		    dialog_resolu.registerForEvent(new Event(){
			        public void onSelect(int p){
				            ssppns.edit().putInt("_resolu_pos", p).putInt("_width", list1_v.get(p)[0]).putInt("_height", list1_v.get(p)[1]).apply();
				            rrv.setText(list1.get(p));
				        }
			    });
			
			int mb = 1024*1024;
			final ArrayList<Integer> values_qua = new ArrayList();
			values_qua.add(mb*200);
			values_qua.add(mb*150);
			values_qua.add(mb*100);
			values_qua.add(mb*80);
			values_qua.add(mb*60);
			values_qua.add(mb*40);
			values_qua.add(mb*35);
			values_qua.add(mb*20);
			values_qua.add(mb*10);
			values_qua.add(mb*5);
			values_qua.add(mb*3);
			values_qua.add(mb);
			values_qua.add(1024*500);
			values_qua.add(1024*100);
			
			final ArrayList<String> keys_qua = new ArrayList();
			keys_qua.add("200Mbps");
			keys_qua.add("150Mbps");
			keys_qua.add("100Mbps");
			keys_qua.add("80Mbps");
			keys_qua.add("60Mbps");
			keys_qua.add("40Mbps");
			keys_qua.add("35Mbps");
			keys_qua.add("20Mbps");
			keys_qua.add("10Mbps");
			keys_qua.add("5Mbps");
			keys_qua.add("3Mbps");
			keys_qua.add("1Mbps");
			keys_qua.add("500kbps");
			keys_qua.add("100kbps");
			
			
			dialog_qua = new ListDialog(keys_qua);
			dialog_qua.setAnchor(imageview6);
			dialog_qua.registerForEvent(new Event(){
			        public void onSelect(int p){
				            ssppns.edit().putInt("_qua_rate_pos", p).putInt("_qua_rate", values_qua.get(p)).apply();
				            qrv.setText(keys_qua.get(p));
				        }
			    });
			
			
			
			final ArrayList<String> list = new ArrayList();
			list.add("12fps");
			list.add("15fps");
			list.add("25fps");
			list.add("30fps");
			list.add("50fps");
			list.add("60fps");
			
		    final ArrayList<Integer> list_vv = new ArrayList();
			list_vv.add(12);
			list_vv.add(15);
			list_vv.add(25);
			list_vv.add(30);
			list_vv.add(50);
			list_vv.add(60);
			
		    
			dialog_fps = new ListDialog(list);
			dialog_fps.setAnchor(imageview5);
			dialog_fps.registerForEvent(new Event(){
			        public void onSelect(int p){
				            ssppns.edit().putInt("_fps_pod", p).putInt("_fps", list_vv.get(p)).apply();
				            frv.setText(list.get(p));
				        }
			    });
		    
		    
		    
		    final ArrayList<String> out_f_list = new ArrayList();
			out_f_list.add("MPEG-4");
			out_f_list.add("3gp");
			out_f_list.add("Webm");
		    out_f_list.add("MPEG-2");
		    
			dialog_format = new ListDialog(out_f_list);
			dialog_format.setAnchor(imageview13);
		    dialog_format.registerForEvent(new Event(){
			        public void onSelect(int p){
				            ssppns.edit().putString("_out_formate", out_f_list.get(p)).apply();
				            textview13.setText(out_f_list.get(p));
				        }
			    });
			
		    
		    dialog_resolu.select(ssppns.getInt("_resolu_pos", 0));
		    dialog_qua.select(ssppns.getInt("_qua_rate_pos", 8));
		    dialog_fps.select(ssppns.getInt("_fps_pod", 3));
		    int vzvhg = out_f_list.indexOf(ssppns.getString("_out_formate", ""));
		    if(vzvhg >= 0){
			    dialog_format.select(vzvhg);
			    }else{
			       dialog_format.select(0); 
			    }
		    
		    switch1.setChecked(ssppns.getBoolean("_use_mic", true));
		    switch2.setChecked(ssppns.getBoolean("_record_screen", true));
	}
	
	
	class ListDialog{
			
			private PopupWindow popup;
			private LinearLayout back_lay, layoutt;
			private View anchor;
			private ArrayList<String> list;
			private ArrayList<ImageView> ckbox_list = new ArrayList();
			private Event event;
			
			ListDialog(ArrayList li_){
					list = li_;
					LinearLayout layout08 = (LinearLayout) getLayoutInflater().inflate(R.layout.hgg, null);
					back_lay = layout08.findViewById(R.id.dialog_back);
					
					ViewGroup g = (ViewGroup) back_lay.getParent();
					if(g != null){
							g.removeView(back_lay);
					}
					
					ScrollView sv = new ScrollView(getBaseContext());
					sv.setVerticalScrollBarEnabled(false);
					sv.addView(back_lay);
					
					popup = new PopupWindow();
					popup.setWidth(-2);
					popup.setHeight(-2);
					popup.setContentView(sv);
					popup.setTouchable(true);
					popup.setOutsideTouchable(false);
					popup.setAnimationStyle(android.R.style.Animation_Dialog);
					popup.setBackgroundDrawable(new BitmapDrawable());
					popup.setOnDismissListener(new PopupWindow.OnDismissListener(){
							public void onDismiss(){
									((FrameLayout)getWindow().getDecorView()).removeView(layoutt);
							}
					});
					
					more();
			}
			
			void more(){
					for(int u = 0; u < list.size(); u++){
							LinearLayout layout = (LinearLayout) getLayoutInflater().inflate(R.layout.hgg, null).findViewById(R.id.lay0);
							TextView text_v = layout.findViewById(R.id.text_);
							ImageView img_ckb = layout.findViewById(R.id.ckbox); 
							
							//showMessage((text_v == null)+"");
							
							
							ViewGroup ghg = (ViewGroup) layout.getParent();
							if(ghg != null){
									ghg.removeView(layout);
							}
							
							layout.setId(u);
							ckbox_list.add(img_ckb);
							
							text_v.setText(list.get(u));
							img_ckb.setImageDrawable(getResources().getDrawable(R.drawable.unchecked));
							
							back_lay.addView(layout);
							
							layout.setOnClickListener(new View.OnClickListener() {
									public void onClick(View vi) {
											select(vi.getId());
											close();
									}
							});
							
					}
			}
			
			void select(int p){
					for(int i = 0; i < ckbox_list.size(); i++){
							if(i == p){
									ckbox_list.get(i).setImageDrawable(getResources().getDrawable(R.drawable.checked));
							}else{
									
									ckbox_list.get(i).setImageDrawable(getResources().getDrawable(R.drawable.unchecked));
							}
					}  
			        if(event != null){
										event.onSelect(p);
								} 
			}
			
			void setAnchor(View v){
					anchor = v;  
			}
			
			void registerForEvent(Event ev){
					event = ev;
			}
			
			void showPopup(){
					layoutt = new LinearLayout(getBaseContext());
					layoutt.setBackgroundColor(Color.BLACK);
					layoutt.setAlpha(0.4f);
					layoutt.setOnClickListener(new View.OnClickListener() {
							public void onClick(View _view) {
									close();
							}
					});
					((FrameLayout)getWindow().getDecorView()).addView(layoutt, new FrameLayout.LayoutParams(-1,-1));
					popup.showAsDropDown(anchor, 0,0);
			}
			
			void close(){
					if(isShowing())
					popup.dismiss(); 
			}
			
			boolean isShowing(){
					return popup.isShowing();
			}
			
	} 
	
	
	interface Event{
			void onSelect(int p);
	}
	
	
	int getWidth(){
		   return window_service.getWidth(this); 
	}
	
	int getHeight(){
		    return MainActivity.getHeight(this);
	}
	
	
	{
			
			
			
			
			
			
			
			
			
			
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}