package com.mrc.rcdit;

import android.service.quicksettings.Tile;
import android.service.quicksettings.TileService;
import android.content.Intent;
import android.os.Build;

public class tile extends TileService {
	
	@Override
	public void onTileAdded() {
		super.onTileAdded();
	}
	
	@Override
	public void onStartListening() {
		super.onStartListening();
	}
	
	@Override
	public void onStopListening() {
		super.onStopListening();
	}
	
	@Override
	public void onTileRemoved() {
		super.onTileRemoved();
	}
	
	@Override
	public void onClick() {
		super.onClick();
		if(MainActivity.allow_all_Permission(this)){
			sendBroadcast(new Intent(Intent.ACTION_CLOSE_SYSTEM_DIALOGS));
			Intent intn = new Intent();
			intn.setAction("fromReceiver");
			intn.setClass(getApplicationContext(), window_service.class);
			startService(intn);
			
			if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
				startForegroundService(intn);
			} else {
				startService(intn);
			}
		}else{
			Intent inn = new Intent();
			inn.setClass(this, MainActivity.class);
			inn.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
			startActivity(inn);
		}
	}
	
	public void onUnlock() {
		
	}
	
	public void onLongClick() {
		
	}
	
	public void onTileLongClick() {
		
	}
	
	
}
